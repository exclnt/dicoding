import {defineConfig} from 'cypress';

export default defineConfig({
  e2e: {
    setupNodeEvents(on, config) {
      // implement node event listeners here
    },
    baseUrl: 'http://localhost:5173', // Vite default port
    video: false,
    supportFile: false,
    allowCypressEnv: false,
  },
});
